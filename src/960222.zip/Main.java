import java.awt.Color;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) throws Exception {
		long startTime = System.currentTimeMillis();
		int imageWidth = 1000;
		int imageHeight = 1000;
		Image image = new Image(imageWidth, imageHeight);		
		
		double ambient, diffuse, specular;
		
		// Colours ----------------------------------------------------------
		Color cyan = Color.CYAN;
		Color green = Color.GREEN;
		Color magenta = Color.MAGENTA;
		Color yellow = Color.YELLOW;
		Color white = Color.WHITE;
		Color red = Color.RED;
		Color gold = new Color(212, 175, 55);
		Color silver = new Color(192,192,192);
		Color orange = Color.ORANGE;
		Color lightGrey = Color.LIGHT_GRAY;
		Color darkRed = new Color(139,0,0);
		Color bronze = new Color(205,127,50);

		// Buddha Camera ----------------------------------------------------
//		Point origin = new Point(0,0.2,0.5);
//		Vector up = new Vector(0,1,0);
//		Point lookAt = new Point(0,0.15,0);
		// Bunny Camera -----------------------------------------------------
		Point origin = new Point(0,0.2,0.5);
		Vector up = new Vector(0,1,0);
		Point lookAt = new Point(0,0.1,0);
		Scene scene = new Scene();
		Color[] colours = {gold};

		scene.readSceneFile("Bunny_Points_VeryHigh.txt","Bunny_Tris_VeryHigh.txt",colours);
	
		// Normal Camera ----------------------------------------------------
//		Point origin = new Point(0,0,8);
//		Vector up = new Vector(0,1,0);
//		Point lookAt = new Point(0,0,0);
		
		double fov = 15;
		double aspectRatio = image.getAspectRatio();
		Camera camera = new Camera(origin, up, lookAt, fov, aspectRatio);
		// -----------------------------------------------------------------
		
		// Following block used to test scenes -----------------------------
		
		Point floor = new Point(0,-1,0);
		Vector surface = new Vector(0,1,0);
		ambient = 0.4;
		diffuse = 0.4;
		specular = 0;
		Plane plane  = new Plane(floor, surface, red, ambient, diffuse, specular);
		
		Point centre = new Point(0, -0.5, -4);
		double radius = 0.5;
		Sphere s1 = new Sphere(centre, radius, lightGrey, 0.4, 0.6, 0.8);
		
		Point c2 = new Point(1.4,-0.65, 2);
		double r2 = 0.35;
		Sphere s2 = new Sphere(c2, r2, lightGrey, 0.4, 0.6, 0.4);
		
		Point c3 = new Point(1,-0.6,-1);
		double r3 = 0.4;
		Sphere s3 = new Sphere(c3, r3, lightGrey, 0.4, 0.6, 0.4);
		
		Point c4 = new Point(-1.4,-0.65, 2);
		Sphere s4 = new Sphere(c4, r2, lightGrey, 0.4, 0.6, 0.4);
		
		Point c5 = new Point(-1,-0.6,-1);
		Sphere s5 = new Sphere(c5, r3, lightGrey, 0.4, 0.6, 0.4);
		
		Point c6 = new Point(0, -0.65, 0);
		Sphere s6 = new Sphere(c6, r2, lightGrey, 0.4, 0.6, 0.4);
		
		Point c7 = new Point(0, 0.75, -20);
		double r7 = 1.75;
		Sphere s7 = new Sphere(c7, r7, lightGrey, 0.4, 0.6, 0.4);
		
		Point c8 = new Point(0.7, -0.7, 1.5);
		double r8 = 0.3;
		Sphere s8 = new Sphere(c8, r8, lightGrey, 0.4, 0.6, 0.4);
		
		Point c9 = new Point(-0.7, -0.7, 1.5);
		double r9 = 0.3;
		Sphere s9 = new Sphere(c9, r9, lightGrey, 0.4, 0.6, 0.4);
		
		Point c10 = new Point(0.27, -0.75, 2.5);
		double r10 = 0.25;
		Sphere s10 = new Sphere(c10, r10, lightGrey, 0.4, 0.6, 0.4);
		
		Point c11 = new Point(-0.27, -0.75, 2.5);
		double r11 = 0.25;
		Sphere s11 = new Sphere(c11, r11, lightGrey, 0.4, 0.6, 0.4);
		
		Point c12 = new Point(-0.8, -0.8, 2.85);
		double r12 = 0.2;
		Sphere s12 = new Sphere(c12, r12, lightGrey, 0.4, 0.6, 0.4);
		
		Point c13 = new Point(2.5, -0.2, -6);
		double r13 = 0.8;
		Sphere s13 = new Sphere(c13, r13, lightGrey, 0.4, 0.6, 0.4);
		
		Point c14 = new Point(-2.5, -0.2, -6);
		double r14 = 0.8;
		Sphere s14 = new Sphere(c14, r14, lightGrey, 0.4, 0.6, 0.4);
		
		Point c15 = new Point(-2.5, -0.2, 6);
		double r15 = 0.8;
		Sphere s15 = new Sphere(c15, r15, lightGrey, 0.4, 0.6, 0.4);
		
		Point c16 = new Point(2.5, -0.2, 6);
		double r16 = 0.8;
		Sphere s16 = new Sphere(c16, r16, lightGrey, 0.4, 0.6, 0.4);
		
		Point c17 = new Point(-0.8, -0.4, -6);
		double r17 = 0.6;
		Sphere s17 = new Sphere(c17, r17, lightGrey, 0.4, 0.6, 0.4);
		
		Point c18 = new Point(0.8, -0.4, -6);
		double r18 = 0.6;
		Sphere s18 = new Sphere(c18, r18, lightGrey, 0.4, 0.6, 0.4);
		
		Point c19 = new Point(1, -0.2, 12);
		double r19 = 0.8;
		Sphere s19 = new Sphere(c19, r19, lightGrey, 0.4, 0.6, 0.4);
		
		Point c20 = new Point(-1, -0.2, 12);
		double r20 = 0.8;
		Sphere s20 = new Sphere(c20, r20, lightGrey, 0.4, 0.6, 0.4);
		
		Point c21 = new Point(-1.2, -0.8, 3.5);
		double r21 = 0.2;
		Sphere s21 = new Sphere(c21, r21, lightGrey, 0.4, 0.6, 0.4);
		
		Point c22 = new Point(1.2, -0.8, 3.5);
		double r22 = 0.2;
		Sphere s22 = new Sphere(c22, r22, lightGrey, 0.4, 0.6, 0.4);
		
		Point c23 = new Point(0.1, 0.3, 2.85);
		double r23 = 0.2;
		Sphere s23 = new Sphere(c23, r23, lightGrey, 0.4, 0.6, 0.4);
		
		Point c24 = new Point(0, 0.5, 18);
		double r24 = 1.5;
		Sphere s24 = new Sphere(c24, r24, lightGrey, 0.4, 0.6, 0.4);
		
//		Point p1 = new Point(-3, -1, -4);
//		Point p2 = new Point(-5.5, -1, -5);
//		Point p3 = new Point(-4.25, -0.75, -4.5);
		Point p1 = new Point(5, -1, 18);
		Point p2 = new Point(8, -1, 25);
		Point p3 = new Point(4.75, 2, 22);
		Triangle t1 = new Triangle(p1, p2, p3, cyan, 0.4, 0.6, 0);
//		
		Point p4 = new Point(3, -1, 25);
		Triangle t2 = new Triangle(p1,p3,p4, cyan, 0.4,0.6,0);
		Triangle t3 = new Triangle(p2, p1, p4, cyan, 0.4, 0.6, 0);
//		Point min = new Point(-1, -1, 0);
//		Point max = new Point(1, 0, 4.5);
//		Box box = new Box(min, max);
//		Scene scene = new Scene(box);
		
//		scene.addToShapesList(plane);
//		scene.addToShapesList(s7);
//
//		scene.addToShapesList(s14);
//		scene.addToShapesList(s13);
//		scene.addToShapesList(s17);
//		scene.addToShapesList(s18);
//		scene.addToShapesList(s24);
//		scene.addToShapesList(s1);
//		scene.addToShapesList(s2);
//		scene.addToShapesList(s3);
//		scene.addToShapesList(s4);
//		scene.addToShapesList(s5);
//		scene.addToShapesList(s6);
//		scene.addToShapesList(s8);
//		scene.addToShapesList(s9);
//		scene.addToShapesList(s10);
//		scene.addToShapesList(s11);
//		scene.addToShapesList(s12);
//		scene.addToShapesList(s15);
//		scene.addToShapesList(s16);
//		scene.addToShapesList(s19);
//		scene.addToShapesList(s20);
//		scene.addToShapesList(s21);
//		scene.addToShapesList(s22);
//		scene.addToShapesList(s23);

		
		
//		scene.addToShapesList(t1);
//		scene.addToShapesList(t2);
//		scene.addToShapesList(t3);


		// ------------------------------------------------------------------

		// JACKS MEGA GAY SCENE  - - - - - - - - - - - - - - - - - - -
		
//		Point p1 = new Point(0,-0.3,-2);
//        Point p2 = new Point(1.5,-0.5,0);
//        Point p3 = new Point(-1.5,-0.5,0);
//        Point p4 = new Point(0,-0.6,2);
//        
//		Color steel = new Color(192,192,192);
//
//        Sphere s1 = new Sphere(p1, 0.7, Color.LIGHT_GRAY, 0.4, 0.4, 1);
//        Sphere s2 = new Sphere(p2, 0.5, Color.MAGENTA, 0.2, 0.5, 0);
//        Sphere s3 = new Sphere(p3, 0.5, Color.ORANGE, 0.2, 0.5, 0);
//        Sphere s4 = new Sphere(p4, 0.4, Color.BLUE, 0.2, 0.5, 0);
//        
//		scene.addToShapesList(s1);
//		scene.addToShapesList(s2);
//		scene.addToShapesList(s3);
//		scene.addToShapesList(s4);
        // ------------------------------------------------------------------
		
		// Light sources ----------------------------------------------------
//		Point position = new Point(3, 4, 10);
//		double intensity = 1;
//		Light light = new Light(position, intensity, white);
		
		Point lightPos = new Point(-1,6,5);
		double intensity2 = 1;
		Light light2 = new Light(lightPos, intensity2, white);
		
//		scene.addToLightsList(light);
		scene.addToLightsList(light2);
		// ------------------------------------------------------------------
		


		
		System.out.println("Ray tracing scene now");
		image.rayTrace(camera, scene);
		image.save();
		System.out.println(Image.intersectionCheckCounter + " intersection checks");

		long completionTime = System.currentTimeMillis();
		long time = completionTime - startTime;

		System.out.println("Done");
		System.out.println("Time taken: " + time/1000.0);
	}

}
